package com.example.coolnyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class HomeScreen extends AppCompatActivity {


    String CATID="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        ImageView imgDeguster = (ImageView)findViewById(R.id.imgDeguster);

        imgDeguster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeScreen.this, MainActivity.class);
                intent.putExtra("catID","3");
                startActivity(intent);
            }
        });


        ImageView imgOffrir = (ImageView)findViewById(R.id.imgOffrir);

        imgOffrir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeScreen.this, MainActivity.class);
                intent.putExtra("catID","2");
                startActivity(intent);
            }
        });


        ImageView imgPersonnaliser = (ImageView)findViewById(R.id.imgPersonnaliser);
        imgPersonnaliser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HomeScreen.this, biscuitpersonnaliser.class);
                startActivity(intent);
            }
        });





    }
}